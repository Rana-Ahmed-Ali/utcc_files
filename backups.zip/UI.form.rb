 _____________
|			  |	roll_no :__________ gender :__________
|			  |	name :____________________
|	  pic	  |	father_name :____________________
|			  |	phone_personal :____________________
|			  |	phone_home :____________________
|_____________|	phone_relatives :____________________

id :____________________    address :________________________________________

course_id :____________________	class_time_id :____________________	course_duration_id :____________________

submitted_fees :____________________  discounted_fees :____________________ RemainingFee :____________________

admission_date :____________________  status_id :____________________   



email :__________________   date_of_birth :__________________   blood_group_id :________  qualification_id :__________________