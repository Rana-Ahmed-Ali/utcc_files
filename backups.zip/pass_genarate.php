<?php
// $password = 'Roar';
// $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
// echo $hashedPassword;
// INSERT INTO users (username, password) VALUES ('UTCC', MD5('Roar'));
?>